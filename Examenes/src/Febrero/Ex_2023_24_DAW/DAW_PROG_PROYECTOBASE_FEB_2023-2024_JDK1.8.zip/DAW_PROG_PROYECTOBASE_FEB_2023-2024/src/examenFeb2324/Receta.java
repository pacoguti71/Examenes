package examenFeb2324;

/**
 * Ejercicio 3. Clase Receta
 * @author Nombre y apellidos del alumno/a
 */
public class Receta {
    
    // Atributos
    
    

    /**
     * Constructor de 4 par�metros que genera un objeto de tipo Receta. 
     * @param nombre
     * @param autor
     * @param duracion
     * @param numIngredientes
     * @throws 
     */
   
        
       
    

    /**
     * Constructor de 3 par�metros que genera un objeto de tipo Receta. 
     * @param nombre
     * @param duracion
     * @param numIngredientes
     * @throws 
     */
    
    
    
    /**
     * Actualiza la duraci�n de la receta.
     * @param nuevaDuracion
     * @return 
     */
   
    

    /**
     * Obtiene la informaci�n de la receta con formato.
     * @return 
     */
   
    

    /**
     * Imprime la informaci�n de la receta, mostrando cada campo en una l�nea. 
     */
    
    
    

    /**
     * Devuelve si la receta es "LARGA", "MEDIA" o "R�PIDA". 
     * @return 
     */
    
    
    
    
    /**
     * M�todo est�tico que devuelve un entero con la cantidad de recetas creadas. 
     * @return 
     */
    
    
    

    /**
     * Programa de pruebas. 
     * @param args argumentos de consola
     */
    public static void main(String[] args) {
        
        
      
    }
}
