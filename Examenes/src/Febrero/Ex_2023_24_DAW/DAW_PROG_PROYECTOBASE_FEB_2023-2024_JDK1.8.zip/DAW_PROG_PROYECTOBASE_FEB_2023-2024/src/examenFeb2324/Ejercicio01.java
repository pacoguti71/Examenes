package examenFeb2324;

import java.time.DateTimeException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Ejercicio 1. Intensidad lum�nica
 * @author Nombre y apellidos del alumno/a
 */
public class Ejercicio01 {

    public static void main(String args[]) {
    
    //----------------------------------------------
    //          Declaraci�n de variables 
    //----------------------------------------------


    

    
    
    //----------------------------------------------
    //               Entrada de datos 
    //                       +
    //                 Procesamiento 
    //----------------------------------------------
    
    
    

    //----------------------------------------------
    //          Salida de resultados 
    //----------------------------------------------
        System.out.println(resultado);
    }
}
