package examenFeb2324;

/**
 * Ejercicio 2. Operaciones con arrays
 * @author Nombre y apellidos del alumno/a
 */
public class Ejercicio02 {

    public static void main(String[] args) {

        //-------------------------------------------------------------------------
        //                        Declaraci�n de variables 
        //-------------------------------------------------------------------------
        //Variables de entrada
        int[] arrayA = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        int[] arrayB = { 4, 6, 2, 1, 7, 5, 2, 8, 1, 3 };
        
        

        //-------------------------------------------------------------------------
        //                              Procesamiento
        //-------------------------------------------------------------------------
        
        
        

        //-------------------------------------------------------------------------
        //  Salida de resultados (no modifiques lo siguiente, debe funcionar as�)
        //-------------------------------------------------------------------------
        System.out.println("EJERCICIO 2. OPERACIONES CON ARRAYS");
        System.out.println("---------------------------------------------------------------------");
        System.out.println("- Array A (hacia adelante):\t\t" + array1);
        System.out.println("- Array B (hacia adelante):\t\t" + array2);
        System.out.println("- Array B (mostrado al rev�s):\t\t" + array2atras);

        System.out.println("\nRESULTADO");
        System.out.println("---------------------------------------------------------------------");
        System.out.println("- Array Resultado (hacia adelante):\t" + resultado);
        System.out.println("\nSuma de todos valores del array resultado:  " + suma);
    }
}